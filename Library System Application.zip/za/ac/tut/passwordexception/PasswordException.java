package za.ac.tut.passwordexception;

public class PasswordException extends Exception{

	public PasswordException(String ErrorMsg) {
		super(ErrorMsg);
	}

}
