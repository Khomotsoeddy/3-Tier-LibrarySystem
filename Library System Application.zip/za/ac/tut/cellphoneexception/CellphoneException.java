package za.ac.tut.cellphoneexception;

public class CellphoneException  extends Exception{

	public CellphoneException(String ErrorMsg) {
		super(ErrorMsg);
	}


}
