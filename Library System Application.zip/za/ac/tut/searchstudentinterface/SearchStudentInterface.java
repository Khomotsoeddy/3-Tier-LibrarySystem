package za.ac.tut.searchstudentinterface;

import javafx.event.ActionEvent;

public interface SearchStudentInterface {
 
	public void searchStudent(ActionEvent e);
	public void removeStudent(ActionEvent e);
	public void exitWindow(ActionEvent e);
}
	