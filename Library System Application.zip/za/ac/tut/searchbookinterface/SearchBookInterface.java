package za.ac.tut.searchbookinterface;

import javafx.event.ActionEvent;

public interface SearchBookInterface {
	
	public void searchBook(ActionEvent e);
	public void done(ActionEvent e);
	public void removeBook(ActionEvent e);
}
