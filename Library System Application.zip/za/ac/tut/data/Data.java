package za.ac.tut.data;

public interface Data {
	String ErrorMsg = " is invalid. Please enter the correct one";
	int MIN = 1;
	int IdMAX = 13;
	int StudNoMAX = 9;
	String LoginError = "";
	int isbnMAX = 15;
	int cellMAX = 10;
	int passwordMIN = 8;
	int passwordMAX = 16;
}
