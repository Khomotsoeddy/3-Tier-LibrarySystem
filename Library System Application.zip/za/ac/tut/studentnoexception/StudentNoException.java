package za.ac.tut.studentnoexception;

public class StudentNoException extends Exception{

	public StudentNoException(String ErrorMsg) {
		super(ErrorMsg);
	}

	
}
