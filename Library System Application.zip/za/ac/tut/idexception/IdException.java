package za.ac.tut.idexception;

public class IdException extends Exception{

	public IdException(String ErrorMsg) {
		super(ErrorMsg);
	}

}
