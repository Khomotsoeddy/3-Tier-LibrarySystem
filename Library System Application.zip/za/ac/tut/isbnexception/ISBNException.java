package za.ac.tut.isbnexception;

public class ISBNException extends Exception {

	public ISBNException(String ErrorMsg) {
		super(ErrorMsg);
	}
	
}
