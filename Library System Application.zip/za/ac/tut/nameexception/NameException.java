package za.ac.tut.nameexception;

public class NameException extends Exception{

	public NameException(String ErrorMsg) {
		super(ErrorMsg);
	}


}
