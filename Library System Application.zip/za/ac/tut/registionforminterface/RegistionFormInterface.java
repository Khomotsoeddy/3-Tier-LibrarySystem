package za.ac.tut.registionforminterface;

import javafx.event.ActionEvent;

public interface RegistionFormInterface {

	public void pressedSubmitButton(ActionEvent e);
	public void cancelButtonPressed(ActionEvent e);
	public void restartButtonPressed(ActionEvent e);
}
