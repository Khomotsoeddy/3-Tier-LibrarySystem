package za.ac.tut.addbookinterface;

import javafx.event.ActionEvent;

public interface AddBookInterface {

	public void addBooks(ActionEvent e);
	public void cancel(ActionEvent e);
}
