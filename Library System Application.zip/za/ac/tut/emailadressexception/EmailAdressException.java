package za.ac.tut.emailadressexception;

public class EmailAdressException extends Exception{

	public EmailAdressException(String ErrorMsg) {
		super(ErrorMsg);
	}


}
